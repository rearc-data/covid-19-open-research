# flake8: noqa

from pandas.core.computation.eval import eval
